#!/bin/bash
while true
    do 
        moti
        sleep 1m 
    done
